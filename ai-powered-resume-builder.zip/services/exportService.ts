import { Document, Packer, Paragraph, TextRun, AlignmentType, convertInchesToTwip } from 'docx';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Resume } from '../types';

// ========== PDF EXPORT ==========

export const exportAsPdf = async (containerId: string): Promise<void> => {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error(`Container with id "${containerId}" not found for PDF export.`);
    alert("Error: Could not find resume content to export.");
    return;
  }
  
  const highlightedElements = container.querySelectorAll('.bg-red-100');
  
  highlightedElements.forEach(el => el.classList.remove('bg-red-100'));

  try {
    const canvas = await html2canvas(container, { 
      scale: 2,
      useCORS: true,
      logging: false,
    });
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'pt',
      format: 'a4'
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    const imgHeightInPdf = (canvasHeight * pdfWidth) / canvasWidth;

    let heightLeft = imgHeightInPdf;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeightInPdf);
    heightLeft -= pdfHeight;

    while (heightLeft > 0) {
      position -= pdfHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeightInPdf);
      heightLeft -= pdfHeight;
    }
    
    pdf.save('resume.pdf');

  } catch (error) {
    console.error("Error generating PDF:", error);
    alert("An error occurred while generating the PDF.");
  } finally {
    highlightedElements.forEach(el => el.classList.add('bg-red-100'));
  }
};


// ========== DOCX EXPORT ==========

const createSectionTitle = (text: string) => {
  return new Paragraph({
    children: [new TextRun({ text, size: 24, bold: true, allCaps: true })],
    spacing: { before: 200, after: 100 },
    border: { bottom: { color: "auto", space: 1, style: "single", size: 6 } },
  });
};

export const exportAsDocx = (data: Resume): void => {
  const docChildren: Paragraph[] = [];

  // --- Header ---
  docChildren.push(new Paragraph({
    children: [new TextRun({ text: data.full_name, bold: true, size: 44 })],
    alignment: AlignmentType.CENTER
  }));
  const contactParts = [data.phone, data.email, data.city, data.country].filter(Boolean);
  docChildren.push(new Paragraph({
    children: [new TextRun({ text: contactParts.join(' | '), size: 18 })],
    alignment: AlignmentType.CENTER
  }));
  const linkParts = [data.linkedin_url, data.portfolio_url].filter(Boolean);
  if (linkParts.length > 0) {
    docChildren.push(new Paragraph({
      children: [new TextRun({ text: linkParts.join(' | '), size: 18, style: 'Hyperlink' })],
      alignment: AlignmentType.CENTER
    }));
  }
  
  // --- Summary ---
  if (data.summary) {
    docChildren.push(createSectionTitle("Summary"));
    docChildren.push(new Paragraph({ children: [new TextRun(data.summary)] }));
  }

  // --- Skills ---
  const allSkills = [...data.skills_core, ...data.skills_tools, ...data.skills_soft];
  if (allSkills.length > 0) {
    docChildren.push(createSectionTitle("Skills"));
    docChildren.push(new Paragraph({ children: [new TextRun(allSkills.join(' • '))] }));
  }

  // --- Experience ---
  if (data.work_experience?.length > 0) {
    docChildren.push(createSectionTitle("Experience"));
    data.work_experience.forEach(job => {
      docChildren.push(new Paragraph({
        children: [
          new TextRun({ text: job.title, bold: true, size: 22 }),
          new TextRun({ text: `\t${job.start_date} - ${job.end_date || 'Present'}`, size: 20 }),
        ],
        tabStops: [{ type: 'right', position: convertInchesToTwip(6.5) }]
      }));
      docChildren.push(new Paragraph({
        children: [new TextRun({ text: `${job.employer}${job.location ? ', ' + job.location : ''}`, italics: true })],
      }));
      job.achievements?.forEach(ach => {
        docChildren.push(new Paragraph({
          children: [new TextRun(ach)],
          bullet: { level: 0 }
        }));
      });
      if (job.tech_stack?.length > 0) {
        docChildren.push(new Paragraph({
          children: [
            new TextRun({ text: "Tech Stack: ", bold: true }),
            new TextRun(job.tech_stack.join(', ')),
          ],
          spacing: { before: 100 }
        }));
      }
    });
  }

  // --- Education ---
  if (data.education?.length > 0) {
    docChildren.push(createSectionTitle("Education"));
    data.education.forEach(edu => {
      docChildren.push(new Paragraph({
        children: [
          new TextRun({ text: edu.degree, bold: true, size: 22 }),
          new TextRun({ text: `\t${edu.graduation_date || ''}`, size: 20 }),
        ],
        tabStops: [{ type: 'right', position: convertInchesToTwip(6.5) }]
      }));
      docChildren.push(new Paragraph({
        children: [new TextRun({ text: edu.institution, italics: true })],
      }));
    });
  }

  const doc = new Document({
    sections: [{
      properties: {
        page: {
            size: {
                width: convertInchesToTwip(8.27), // A4 Width
                height: convertInchesToTwip(11.69), // A4 Height
            },
            margin: {
                top: convertInchesToTwip(0.75),
                right: convertInchesToTwip(0.75),
                bottom: convertInchesToTwip(0.75),
                left: convertInchesToTwip(0.75),
            },
        },
      },
      children: docChildren,
    }],
  });

  Packer.toBlob(doc).then(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'resume.docx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });
};


// ========== CSV EXPORT (for Google Sheets) ==========
const toCsvContent = (data: Resume): string => {
  const rows: string[][] = [];
  
  const escapeCsv = (str: string | undefined | null): string => {
    if (str === null || str === undefined) return '';
    const s = String(str);
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };

  rows.push(['SECTION', 'FIELD', 'VALUE']);
  // Contact Info
  rows.push(['Contact', 'Full Name', escapeCsv(data.full_name)]);
  rows.push(['Contact', 'Email', escapeCsv(data.email)]);
  rows.push(['Contact', 'Phone', escapeCsv(data.phone)]);
  rows.push(['Contact', 'City', escapeCsv(data.city)]);
  rows.push(['Contact', 'Country', escapeCsv(data.country)]);
  rows.push(['Contact', 'LinkedIn URL', escapeCsv(data.linkedin_url)]);
  rows.push(['Contact', 'Portfolio/Github URL', escapeCsv(data.portfolio_url)]);
  
  // Role Info
  rows.push(['Role', 'Target Title', escapeCsv(data.target_role_title)]);
  rows.push(['Role', 'Seniority', escapeCsv(data.seniority_level)]);
  rows.push(['Role', 'Job Family', escapeCsv(data.job_family)]);

  // Summary
  rows.push(['Summary', 'Summary', escapeCsv(data.summary)]);
  
  // Skills
  rows.push(['Skills', 'Core', escapeCsv(data.skills_core.join(', '))]);
  rows.push(['Skills', 'Tools', escapeCsv(data.skills_tools.join(', '))]);
  rows.push(['Skills', 'Soft', escapeCsv(data.skills_soft.join(', '))]);

  // Experience
  if (data.work_experience?.length > 0) {
    data.work_experience.forEach((job, i) => {
      rows.push([`Experience ${i+1}`, 'Title', escapeCsv(job.title)]);
      rows.push([`Experience ${i+1}`, 'Employer', escapeCsv(job.employer)]);
      rows.push([`Experience ${i+1}`, 'Location', escapeCsv(job.location)]);
      rows.push([`Experience ${i+1}`, 'Dates', `${escapeCsv(job.start_date)} - ${escapeCsv(job.end_date)}`]);
      job.achievements?.forEach((ach, j) => {
        rows.push([`Experience ${i+1}`, `Achievement ${j+1}`, escapeCsv(ach)]);
      });
      rows.push([`Experience ${i+1}`, 'Tech Stack', escapeCsv(job.tech_stack?.join(', '))]);
    });
  }

  // Education
  if (data.education?.length > 0) {
      data.education.forEach((edu, i) => {
          rows.push([`Education ${i+1}`, 'Degree', escapeCsv(edu.degree)]);
          rows.push([`Education ${i+1}`, 'Discipline', escapeCsv(edu.discipline)]);
          rows.push([`Education ${i+1}`, 'Institution', escapeCsv(edu.institution)]);
          rows.push([`Education ${i+1}`, 'Graduation Date', escapeCsv(edu.graduation_date)]);
      });
  }

  return rows.map(row => row.join(',')).join('\n');
};

export const exportAsCsv = (resumeData: Resume): void => {
  const csvContent = toCsvContent(resumeData);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'resume_data.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
};
