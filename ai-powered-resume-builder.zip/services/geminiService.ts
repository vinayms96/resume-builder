
import { GoogleGenAI } from "@google/genai";
import { Resume } from '../types';

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

type EnhancementContext = 'summary' | 'achievement';

export const enhanceTextWithAI = async (
  text: string, 
  context: EnhancementContext, 
  resumeData: Pick<Resume, 'target_role_title' | 'seniority_level'>
): Promise<string> => {

  if (!process.env.API_KEY) {
    throw new Error("API_KEY is not configured.");
  }
  
  if (!text.trim()) {
    return "";
  }

  let prompt = '';
  const { target_role_title, seniority_level } = resumeData;

  switch (context) {
    case 'summary':
      prompt = `You are an expert resume writer. Rewrite the following professional summary to be concise, impactful, and tailored for a "${target_role_title}" role at a "${seniority_level || 'mid'}" level. Focus on quantifiable achievements and key skills. Keep it to 3-4 sentences.
      
      Original summary:
      "${text}"
      
      Rewritten summary:`;
      break;
    case 'achievement':
      prompt = `You are an expert resume writer. Rewrite the following achievement bullet point for a resume to be more impactful and quantifiable, using the STAR method (Situation, Task, Action, Result) where possible. The target role is "${target_role_title}".
      
      Original achievement:
      "${text}"

      Rewritten achievement (as a single bullet point):`;
      break;
    default:
      throw new Error("Invalid enhancement context");
  }

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    
    // Clean up response, remove potential markdown like starting with "- "
    return response.text.trim().replace(/^- /,'');
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get enhancement from AI. Please check your API key and network connection.");
  }
};
