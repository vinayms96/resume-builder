import React, { useState, useCallback } from 'react';
import { Resume, Template } from './types';
import { INITIAL_RESUME_DATA, SAMPLE_RESUME_DATA, JOB_FAMILY_TEMPLATE_MAP } from './constants';
import Header from './components/Header';
import ResumeForm from './components/ResumeForm';
import ResumePreview from './components/ResumePreview';
import { set, get } from 'lodash-es';
import { exportAsPdf, exportAsDocx, exportAsCsv } from './services/exportService';

// Utility to check if a value is "empty" (null, undefined, empty string, or empty array)
const isValueEmpty = (value: any): boolean => {
  if (value === null || value === undefined || value === '') return true;
  if (Array.isArray(value) && value.length === 0) return true;
  return false;
};

// Utility to get all possible dot-notation paths from the sample data for initial highlighting
const getAllPaths = (obj: object, prefix = ''): string[] => {
  return Object.entries(obj).flatMap(([key, value]) => {
    const newPrefix = prefix ? `${prefix}.${key}` : key;
    if (Array.isArray(value)) {
      if (value.length === 0) return [newPrefix]; // For empty arrays, highlight the array path itself.
      // Always recurse into arrays, creating indexed paths for each item.
      return value.flatMap((item, index) => {
        const itemPrefix = `${newPrefix}.${index}`;
        // Recurse if item is an object, otherwise return the indexed path for the primitive.
        if (typeof item === 'object' && item !== null) {
          return getAllPaths(item, itemPrefix);
        }
        return [itemPrefix];
      });
    }
    if (typeof value === 'object' && value !== null) {
      return getAllPaths(value, newPrefix);
    }
    return [newPrefix];
  });
};


const App: React.FC = () => {
  const [resumeData, setResumeData] = useState<Resume>(INITIAL_RESUME_DATA);
  const [template, setTemplate] = useState<Template>('A');
  const [highlightedFields, setHighlightedFields] = useState<Set<string>>(new Set());
  const [hasUserInteracted, setHasUserInteracted] = useState(false);

  const handleLoadSample = useCallback(() => {
    setResumeData(SAMPLE_RESUME_DATA);
    const newTemplate = JOB_FAMILY_TEMPLATE_MAP[SAMPLE_RESUME_DATA.job_family as keyof typeof JOB_FAMILY_TEMPLATE_MAP] || 'A';
    setTemplate(newTemplate);
    // When loading sample, highlight all fields from the sample
    setHighlightedFields(new Set(getAllPaths(SAMPLE_RESUME_DATA)));
    setHasUserInteracted(true);
  }, []);

  const handleTemplateChange = (newTemplate: Template) => {
    setTemplate(newTemplate);

    // If user hasn't typed anything, just load the full sample.
    if (!hasUserInteracted) {
        handleLoadSample();
        return;
    }

    const newResumeData = JSON.parse(JSON.stringify(resumeData));
    const newHighlights = new Set(highlightedFields);
    let changed = false;

    // Merge sample data into empty fields
    for (const key in SAMPLE_RESUME_DATA) {
        const k = key as keyof Resume;
        if (isValueEmpty(get(resumeData, k))) {
            const sampleValue = SAMPLE_RESUME_DATA[k];
            (newResumeData as any)[k] = sampleValue;
            
             // Add highlights for the newly added sample data
            if (typeof sampleValue === 'object' && sampleValue !== null) {
                const pathsToAdd = getAllPaths({ [k]: sampleValue });
                pathsToAdd.forEach(p => newHighlights.add(p));
            } else {
                newHighlights.add(k);
            }

            changed = true;
        }
    }

    if (changed) {
        setResumeData(newResumeData);
        setHighlightedFields(newHighlights);
    }
  }

  const handleExport = useCallback((format: 'pdf' | 'docx' | 'csv') => {
    switch(format) {
      case 'pdf':
        exportAsPdf('resume-preview-pages-container');
        break;
      case 'docx':
        exportAsDocx(resumeData);
        break;
      case 'csv':
        exportAsCsv(resumeData);
        break;
    }
  }, [resumeData]);

  const handleFieldChange = (path: string, value: any) => {
    setHasUserInteracted(true);
    const newResumeData = JSON.parse(JSON.stringify(resumeData));
    set(newResumeData, path, value);

    // Auto-select template based on job family
    if (path === 'job_family') {
      const newTemplate = JOB_FAMILY_TEMPLATE_MAP[value as keyof typeof JOB_FAMILY_TEMPLATE_MAP] || 'A';
      const currentFamilyTemplate = JOB_FAMILY_TEMPLATE_MAP[resumeData.job_family as keyof typeof JOB_FAMILY_TEMPLATE_MAP] || 'A';
      if (template === currentFamilyTemplate) {
        setTemplate(newTemplate);
      }
    }
    
    setResumeData(newResumeData);

    // Remove highlight for the edited field and any sub-paths (e.g., editing skills_core removes skills_core.0, skills_core.1, etc.)
    setHighlightedFields(prev => {
      const next = new Set<string>();
      for (const field of prev) {
        if (field !== path && !field.startsWith(path + '.')) {
          next.add(field);
        }
      }
      return next;
    });
  };


  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        onLoadSample={handleLoadSample} 
        onExport={handleExport} 
      />
      <main className="flex-grow grid grid-cols-1 lg:grid-cols-2 gap-8 p-4 sm:p-6 lg:p-8 max-w-screen-2xl mx-auto w-full">
        <div className="lg:overflow-y-auto lg:h-[calc(100vh-100px)] pr-4">
          <ResumeForm resumeData={resumeData} onFieldChange={handleFieldChange} />
        </div>
        <div className="lg:overflow-y-auto lg:h-[calc(100vh-100px)]">
           <ResumePreview 
            resumeData={resumeData}
            template={template}
            onTemplateChange={handleTemplateChange}
            highlightedFields={highlightedFields}
          />
        </div>
      </main>
    </div>
  );
};

export default App;