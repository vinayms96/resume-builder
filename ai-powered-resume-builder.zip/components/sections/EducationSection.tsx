
import React from 'react';
import { Education } from '../../types';
import FormSection from '../FormSection';
import Input from '../ui/Input';
import Button from '../ui/Button';

interface EducationSectionProps {
  education: Education[];
  onFieldChange: (path: string, value: any) => void;
}

const EducationSection: React.FC<EducationSectionProps> = ({ education, onFieldChange }) => {
  
  const handleItemChange = (index: number, field: keyof Education, value: string) => {
    onFieldChange(`education.${index}.${field}`, value);
  };
  
  const addItem = () => {
    const newEducation = [...education, { degree: '', institution: '' }];
    onFieldChange('education', newEducation);
  };

  const removeItem = (index: number) => {
    const newEducation = education.filter((_, i) => i !== index);
    onFieldChange('education', newEducation);
  };

  return (
    <FormSection title="Education">
      <div className="space-y-6">
        {education.map((item, index) => (
          <div key={index} className="p-4 border border-gray-200 rounded-md relative space-y-4">
            <Button onClick={() => removeItem(index)} variant="danger" size="sm" className="absolute top-2 right-2">Remove</Button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Degree" value={item.degree} onChange={e => handleItemChange(index, 'degree', e.target.value)} />
              <Input label="Discipline/Major" value={item.discipline || ''} onChange={e => handleItemChange(index, 'discipline', e.target.value)} />
              <Input label="Institution" value={item.institution || ''} onChange={e => handleItemChange(index, 'institution', e.target.value)} />
              <Input label="Graduation Date" value={item.graduation_date || ''} onChange={e => handleItemChange(index, 'graduation_date', e.target.value)} />
            </div>
          </div>
        ))}
      </div>
      <Button onClick={addItem} variant="primary" className="mt-4">Add Education</Button>
    </FormSection>
  );
};

export default EducationSection;
