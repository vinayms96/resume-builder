
import React from 'react';
import { Resume } from '../../types';
import FormSection from '../FormSection';
import Input from '../ui/Input';

interface SkillsSectionProps {
  resumeData: Resume;
  onFieldChange: (path: string, value: any) => void;
}

const SkillsSection: React.FC<SkillsSectionProps> = ({ resumeData, onFieldChange }) => {
  const handleSkillsChange = (field: 'skills_core' | 'skills_tools' | 'skills_soft', value: string) => {
    const skillsArray = value.split(',').map(s => s.trim()).filter(Boolean);
    onFieldChange(field, skillsArray);
  };

  return (
    <FormSection title="Skills">
        <Input 
            label="Core Skills (comma-separated)" 
            id="skills_core" 
            value={resumeData.skills_core.join(', ')} 
            onChange={(e) => handleSkillsChange('skills_core', e.target.value)}
            placeholder="e.g., JavaScript, Cypress, Playwright"
        />
        <Input 
            label="Tools & Technologies (comma-separated)" 
            id="skills_tools" 
            value={resumeData.skills_tools.join(', ')} 
            onChange={(e) => handleSkillsChange('skills_tools', e.target.value)}
            placeholder="e.g., AWS, Jenkins, Docker, JIRA"
        />
        <Input 
            label="Soft Skills (comma-separated)" 
            id="skills_soft" 
            value={resumeData.skills_soft.join(', ')} 
            onChange={(e) => handleSkillsChange('skills_soft', e.target.value)}
            placeholder="e.g., Agile Methodologies, Communication"
        />
    </FormSection>
  );
};

export default SkillsSection;
