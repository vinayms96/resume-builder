
import React from 'react';
import { Resume } from '../../types';
import { enhanceTextWithAI } from '../../services/geminiService';
import FormSection from '../FormSection';
import Textarea from '../ui/Textarea';
import AIAssistButton from '../AIAssistButton';

interface SummarySectionProps {
  resumeData: Resume;
  onFieldChange: (path: string, value: any) => void;
}

const SummarySection: React.FC<SummarySectionProps> = ({ resumeData, onFieldChange }) => {
  const handleEnhance = async () => {
    const enhancedSummary = await enhanceTextWithAI(resumeData.summary, 'summary', resumeData);
    onFieldChange('summary', enhancedSummary);
  };

  return (
    <FormSection title="Professional Summary">
      <Textarea 
        label="Summary" 
        id="summary" 
        value={resumeData.summary} 
        onChange={(e) => onFieldChange('summary', e.target.value)}
        placeholder="A brief, 2-4 sentence summary of your skills and experience."
      />
      <div className="flex justify-end">
        <AIAssistButton onClick={handleEnhance} disabled={!resumeData.summary || !resumeData.target_role_title} />
      </div>
    </FormSection>
  );
};

export default SummarySection;
