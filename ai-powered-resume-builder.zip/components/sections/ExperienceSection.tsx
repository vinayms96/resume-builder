
import React from 'react';
import { WorkItem, Resume } from '../../types';
import { enhanceTextWithAI } from '../../services/geminiService';
import FormSection from '../FormSection';
import Input from '../ui/Input';
import Button from '../ui/Button';
import AIAssistButton from '../AIAssistButton';

interface ExperienceSectionProps {
  workExperience: WorkItem[];
  onFieldChange: (path: string, value: any) => void;
  resumeData: Resume;
}

const ExperienceSection: React.FC<ExperienceSectionProps> = ({ workExperience, onFieldChange, resumeData }) => {

  const handleItemChange = (index: number, field: keyof WorkItem, value: string) => {
    onFieldChange(`work_experience.${index}.${field}`, value);
  };

  const handleAchievementChange = (itemIndex: number, achIndex: number, value: string) => {
    onFieldChange(`work_experience.${itemIndex}.achievements.${achIndex}`, value);
  };
  
  const addAchievement = (itemIndex: number) => {
    const newAchievements = [...(workExperience[itemIndex].achievements || []), ''];
    onFieldChange(`work_experience.${itemIndex}.achievements`, newAchievements);
  };

  const removeAchievement = (itemIndex: number, achIndex: number) => {
    const newAchievements = (workExperience[itemIndex].achievements || []).filter((_, i) => i !== achIndex);
    onFieldChange(`work_experience.${itemIndex}.achievements`, newAchievements);
  };
  
  const addItem = () => {
    const newWorkExperience = [...workExperience, { title: '', employer: '', start_date: '', achievements: [''] }];
    onFieldChange('work_experience', newWorkExperience);
  };

  const removeItem = (index: number) => {
    const newWorkExperience = workExperience.filter((_, i) => i !== index);
    onFieldChange('work_experience', newWorkExperience);
  };
  
  const handleEnhanceAchievement = async (itemIndex: number, achIndex: number) => {
    const originalText = workExperience[itemIndex].achievements?.[achIndex] || '';
    const enhancedText = await enhanceTextWithAI(originalText, 'achievement', resumeData);
    handleAchievementChange(itemIndex, achIndex, enhancedText);
  };

  return (
    <FormSection title="Work Experience">
      <div className="space-y-6">
        {workExperience.map((item, index) => (
          <div key={index} className="p-4 border border-gray-200 rounded-md relative space-y-4">
            <Button onClick={() => removeItem(index)} variant="danger" size="sm" className="absolute top-2 right-2">Remove</Button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Job Title" value={item.title} onChange={e => handleItemChange(index, 'title', e.target.value)} />
              <Input label="Employer" value={item.employer} onChange={e => handleItemChange(index, 'employer', e.target.value)} />
              <Input label="Start Date (e.g., Jan 2021)" value={item.start_date} onChange={e => handleItemChange(index, 'start_date', e.target.value)} />
              <Input label="End Date (e.g., Present)" value={item.end_date || ''} onChange={e => handleItemChange(index, 'end_date', e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Achievements</label>
              <div className="space-y-3">
                {(item.achievements || []).map((ach, achIndex) => (
                  <div key={achIndex} className="flex items-start space-x-2">
                    <div className="relative w-full">
                      <textarea 
                        value={ach}
                        onChange={e => handleAchievementChange(index, achIndex, e.target.value)}
                        rows={3}
                        className="flex-grow block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm sm:text-sm text-gray-900 pr-10"
                        placeholder="Describe a key accomplishment..."
                      />
                      <div className="absolute top-2 right-2">
                         <AIAssistButton 
                           onClick={() => handleEnhanceAchievement(index, achIndex)} 
                           disabled={!ach || !resumeData.target_role_title}
                           showText={false}
                         />
                      </div>
                    </div>
                    <Button onClick={() => removeAchievement(index, achIndex)} variant="danger" size="sm" className="h-8 w-8 p-0 flex items-center justify-center">X</Button>
                  </div>
                ))}
              </div>
              <Button onClick={() => addAchievement(index)} size="sm" className="mt-2">Add Achievement</Button>
            </div>
          </div>
        ))}
      </div>
      <Button onClick={addItem} variant="primary" className="mt-4">Add Experience</Button>
    </FormSection>
  );
};

export default ExperienceSection;
