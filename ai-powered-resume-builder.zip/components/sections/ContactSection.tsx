
import React from 'react';
import { Resume } from '../../types';
import FormSection from '../FormSection';
import Input from '../ui/Input';

interface ContactSectionProps {
  resumeData: Resume;
  onFieldChange: (path: string, value: any) => void;
}

const ContactSection: React.FC<ContactSectionProps> = ({ resumeData, onFieldChange }) => {
  
  return (
    <FormSection title="Contact Information">
      <Input label="Full Name" id="full_name" value={resumeData.full_name} onChange={(e) => onFieldChange('full_name', e.target.value)} required />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label="Email" id="email" type="email" value={resumeData.email} onChange={(e) => onFieldChange('email', e.target.value)} required />
        <Input label="Phone" id="phone" value={resumeData.phone} onChange={(e) => onFieldChange('phone', e.target.value)} required />
        <Input label="City" id="city" value={resumeData.city || ''} onChange={(e) => onFieldChange('city', e.target.value)} />
        <Input label="Country" id="country" value={resumeData.country} onChange={(e) => onFieldChange('country', e.target.value)} required />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input label="LinkedIn URL" id="linkedin_url" value={resumeData.linkedin_url || ''} onChange={(e) => onFieldChange('linkedin_url', e.target.value)} />
        <Input label="Portfolio/Github URL" id="portfolio_url" value={resumeData.portfolio_url || ''} onChange={(e) => onFieldChange('portfolio_url', e.target.value)} />
      </div>
    </FormSection>
  );
};

export default ContactSection;
