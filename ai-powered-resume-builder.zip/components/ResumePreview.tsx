import React, { useLayoutEffect, useRef, useState } from 'react';
import { Resume, Template, TEMPLATE_OPTIONS } from '../types';
import TemplateA from './preview_templates/TemplateA';
import TemplateB from './preview_templates/TemplateB';

interface ResumePreviewProps {
  resumeData: Resume;
  template: Template;
  onTemplateChange: (template: Template) => void;
  highlightedFields: Set<string>;
}

const ResumePreview: React.FC<ResumePreviewProps> = ({ resumeData, template, onTemplateChange, highlightedFields }) => {
  const [pages, setPages] = useState<number[]>([]);
  const contentRef = useRef<HTMLDivElement>(null);
  const a4PageHeightPx = 1123; // A4 height in pixels at 96 DPI
  const pageMarginPx = 48 * 2; // top and bottom padding
  const effectivePageHeight = a4PageHeightPx - pageMarginPx;

  useLayoutEffect(() => {
    if (contentRef.current) {
      const totalHeight = contentRef.current.scrollHeight;
      const pageCount = Math.ceil(totalHeight / effectivePageHeight);
      setPages(Array.from({ length: pageCount || 1 }, (_, i) => i));
    }
  }, [resumeData, template, effectivePageHeight]);

  const renderTemplate = () => {
    switch (template) {
      case 'B': return <TemplateB data={resumeData} highlightedFields={highlightedFields} />;
      default: return <TemplateA data={resumeData} highlightedFields={highlightedFields} />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 sticky top-8">
      {/* Template Selector */}
      <div className="mb-4">
        <label htmlFor="template-select" className="block text-sm font-medium text-gray-700 mb-1">Template</label>
        <select
          id="template-select"
          value={template}
          onChange={(e) => onTemplateChange(e.target.value as Template)}
          className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-gray-900"
        >
          {TEMPLATE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
        </select>
      </div>

      {highlightedFields.size > 0 && (
        <p className="text-xs text-gray-600 italic mb-2 text-center">
          * Highlighted fields are sample content and will update as you type.
        </p>
      )}

      {/* A hidden div to measure the full content height */}
      <div style={{ position: 'absolute', zIndex: -1, top: '-9999px', left: '-9999px', width: '794px' }}>
        <div ref={contentRef} style={{ padding: '48px' }}>
          {renderTemplate()}
        </div>
      </div>
      
      {/* The visible, paginated preview */}
      <div id="resume-preview-pages-container" className="bg-gray-200 p-4 sm:p-8 overflow-auto space-y-4">
        {pages.map((pageIndex) => (
          <div
            key={pageIndex}
            className="bg-white mx-auto shadow-lg overflow-hidden"
            style={{ width: '794px', height: `${a4PageHeightPx}px` }}
          >
            <div style={{ transform: `translateY(-${pageIndex * effectivePageHeight}px)` }}>
              <div style={{ padding: '48px' }}>
                {renderTemplate()}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResumePreview;