import React, { useState, useRef, useEffect } from 'react';
import Button from './ui/Button';

interface HeaderProps {
  onLoadSample: () => void;
  onExport: (format: 'pdf' | 'docx' | 'csv') => void;
}

const Header: React.FC<HeaderProps> = ({ onLoadSample, onExport }) => {
  const [isExportOpen, setIsExportOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsExportOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleExportClick = (format: 'pdf' | 'docx' | 'csv') => {
    onExport(format);
    setIsExportOpen(false);
  };

  return (
    <header className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-10">
      <div className="flex items-center space-x-3">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-600" viewBox="0 0 20 20" fill="currentColor">
          <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356.257l4.118 4.118a1 1 0 001.414 0l4.118-4.118a.999.999 0 01.356-.257l2.644-1.233a1 1 0 000-1.84l-7-3zM3.13 6.39l7-3.111 7 3.111-7 1.4-7-1.4zM5 9.051v3.428a1 1 0 00.293.707l4.414 4.414a1 1 0 001.414 0l4.414-4.414A1 1 0 0015 12.479V9.051L10 11.232 5 9.051z" />
        </svg>
        <h1 className="text-xl font-bold text-gray-800">AI Resume Builder</h1>
      </div>
      <div className="flex items-center space-x-3">
        <Button onClick={onLoadSample} variant="secondary">Load Sample</Button>
        <div className="relative" ref={dropdownRef}>
          <Button onClick={() => setIsExportOpen(!isExportOpen)} variant="primary">
            Export
            <svg className="ml-2 -mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </Button>
          {isExportOpen && (
            <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-20">
              <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
                <button onClick={() => handleExportClick('pdf')} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">PDF</button>
                <button onClick={() => handleExportClick('docx')} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">DOCX</button>
                <button onClick={() => handleExportClick('csv')} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">CSV (for Sheets)</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;