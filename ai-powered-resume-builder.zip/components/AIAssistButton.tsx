import React, { useState } from 'react';

interface AIAssistButtonProps {
  onClick: () => Promise<void>;
  disabled?: boolean;
  showText?: boolean;
}

const AIAssistButton: React.FC<AIAssistButtonProps> = ({ onClick, disabled, showText = true }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    setIsLoading(true);
    try {
      await onClick();
    } catch (error) {
      console.error("AI Assist Error:", error);
      alert((error as Error).message || "An unknown error occurred with AI Assist.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={isLoading || disabled}
      className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-800 disabled:text-gray-400 disabled:cursor-not-allowed"
      title="Enhance with AI"
    >
      {isLoading ? (
        <svg className={`animate-spin h-4 w-4 ${showText ? '-ml-1 mr-2' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${showText ? 'mr-1' : ''}`} viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M11.3 2.05c.812-.293 1.7.13 1.993.942l.295.811a.5.5 0 00.485.343h.823c.928 0 1.57.81 1.258 1.68l-.295.81a.5.5 0 00.343.485v.823c0 .928-.81 1.57-1.68 1.258l-.81-.295a.5.5 0 00-.485.343v.823c0 .928-.81 1.57-1.68 1.258l-.81-.295a.5.5 0 00-.485.343v.823c0 .928-.81 1.57-1.68 1.258l-.81-.295a.5.5 0 00-.485.343v.823c0 .928-.81 1.57-1.68 1.258l-.81-.295a.5.5 0 00-.485-.343h-.823c-.928 0-1.57-.81-1.258-1.68l.295-.81a.5.5 0 00-.343-.485v-.823c0-.928.81-1.57 1.68-1.258l.81.295a.5.5 0 00.485-.343v-.823c0-.928.81-1.57 1.68-1.258l.81.295a.5.5 0 00.485-.343v-.823c0-.928.81-1.57 1.68-1.258l.81.295a.5.5 0 00.485-.343h.823c.928 0 1.57.81 1.258 1.68l-.295.81a.5.5 0 00.343.485v.823c0 .928-.81 1.57-1.68 1.258l-.81-.295a.5.5 0 00-.485-.343h-.823c-.435 0-.832.166-1.13.434L2.05 11.3c-.293.812.13 1.7.942 1.993l.811.295a.5.5 0 00.343.485h.823c.928 0 1.57.81 1.258 1.68l-.295.81a.5.5 0 00.343.485v.823c.928 0 1.57-.81 1.258-1.68l-.295-.81a.5.5 0 00-.343-.485v-.823a.5.5 0 00.343-.485l.295-.81c.293-.812-.13-1.7-.942-1.993L8.7 17.95c-.812.293-1.7-.13-1.993-.942l-.295-.811a.5.5 0 00-.485-.343H5.1c-.928 0-1.57-.81-1.258-1.68l.295-.81a.5.5 0 00-.343-.485v-.823c0-.928.81-1.57 1.68-1.258l.81.295a.5.5 0 00.485-.343V8.9c0-.928.81-1.57 1.68-1.258l.81.295a.5.5 0 00.485-.343V6.47c0-.928.81-1.57 1.68-1.258l.81.295a.5.5 0 00.485-.343h.823c.928 0 1.57.81 1.258 1.68l-.295.81a.5.5 0 00.343.485v.823c0 .928-.81 1.57-1.68 1.258l-.81-.295a.5.5 0 00-.485-.343h-.823c-.928 0-1.57-.81-1.258-1.68l.295-.81a.5.5 0 00-.343-.485V2.873a.5.5 0 00.343-.485L8.7 2.05z" clipRule="evenodd" />
        </svg>
      )}
      {showText && <span>Enhance with AI</span>}
    </button>
  );
};

export default AIAssistButton;