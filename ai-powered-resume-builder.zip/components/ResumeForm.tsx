
import React from 'react';
import { Resume } from '../types';
import ContactSection from './sections/ContactSection';
import RoleSection from './sections/RoleSection';
import SummarySection from './sections/SummarySection';
import SkillsSection from './sections/SkillsSection';
import ExperienceSection from './sections/ExperienceSection';
import EducationSection from './sections/EducationSection';

interface ResumeFormProps {
  resumeData: Resume;
  onFieldChange: (path: string, value: any) => void;
}

const ResumeForm: React.FC<ResumeFormProps> = ({ resumeData, onFieldChange }) => {
  
  return (
    <div className="space-y-6">
      <ContactSection resumeData={resumeData} onFieldChange={onFieldChange} />
      <RoleSection resumeData={resumeData} onFieldChange={onFieldChange} />
      <SummarySection resumeData={resumeData} onFieldChange={onFieldChange} />
      <SkillsSection resumeData={resumeData} onFieldChange={onFieldChange} />
      <ExperienceSection 
        workExperience={resumeData.work_experience} 
        onFieldChange={onFieldChange}
        resumeData={resumeData}
      />
      <EducationSection
        education={resumeData.education}
        onFieldChange={onFieldChange}
      />
    </div>
  );
};

export default ResumeForm;
