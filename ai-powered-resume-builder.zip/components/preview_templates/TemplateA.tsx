import React from 'react';
import { Resume } from '../../types';

interface TemplateProps {
  data: Resume;
  highlightedFields: Set<string>;
}

// A wrapper to apply highlight class. It can check for a direct path match
// or, if `isArray` is true, check if any highlighted path starts with the base path.
const Highlight: React.FC<{ 
  path: string, 
  highlightedFields: Set<string>, 
  children: React.ReactNode, 
  className?: string,
  isArray?: boolean 
}> = ({ path, highlightedFields, children, className, isArray }) => {
  let isHighlighted: boolean;
  
  if (isArray) {
    // For arrays, check if any field starting with this path prefix exists in the set.
    isHighlighted = Array.from(highlightedFields).some(field => field.startsWith(path));
  } else {
    // For single fields, do a direct check.
    isHighlighted = highlightedFields.has(path);
  }

  if (!children) return null;
  return <span className={`${className || ''} ${isHighlighted ? 'bg-red-100' : ''}`}>{children}</span>;
};


const TemplateA: React.FC<TemplateProps> = ({ data, highlightedFields }) => {
  
  const allSkills = [
    ...(data.skills_core || []),
    ...(data.skills_tools || []),
    ...(data.skills_soft || []),
  ];

  return (
    <div className="text-sm font-sans text-black leading-relaxed">
      <header className="text-center mb-6 break-inside-avoid">
        <h1 className="text-3xl font-bold tracking-tight">
          <Highlight path="full_name" highlightedFields={highlightedFields}>{data.full_name || 'Your Name'}</Highlight>
        </h1>
        <p className="mt-1 text-xs text-gray-700">
            <Highlight path="phone" highlightedFields={highlightedFields}>{data.phone}</Highlight>
            {data.phone && data.email ? ' | ' : ''}
            <Highlight path="email" highlightedFields={highlightedFields}>{data.email}</Highlight>
            {(data.phone || data.email) && (data.city || data.country) ? ' | ' : ''}
            <Highlight path="city" highlightedFields={highlightedFields}>{data.city}</Highlight>
            {data.city && data.country ? ', ' : ''}
            <Highlight path="country" highlightedFields={highlightedFields}>{data.country}</Highlight>
        </p>
         <p className="mt-1 text-xs text-gray-700">
            <Highlight path="linkedin_url" highlightedFields={highlightedFields}>{data.linkedin_url}</Highlight>
            {data.linkedin_url && data.portfolio_url ? ' | ' : ''}
            <Highlight path="portfolio_url" highlightedFields={highlightedFields}>{data.portfolio_url}</Highlight>
        </p>
      </header>

      {data.summary && (
        <section className="mb-4 break-inside-avoid">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-black pb-1 mb-2">Summary</h2>
          <p><Highlight path="summary" highlightedFields={highlightedFields}>{data.summary}</Highlight></p>
        </section>
      )}

      {allSkills.length > 0 && (
        <section className="mb-4 break-inside-avoid">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-black pb-1 mb-2">Skills</h2>
          <p className="text-xs">
            <Highlight path="skills_core" highlightedFields={highlightedFields} isArray>{(data.skills_core || []).join(' • ')}</Highlight>
            {data.skills_core?.length > 0 && data.skills_tools?.length > 0 ? ' • ' : ''}
            <Highlight path="skills_tools" highlightedFields={highlightedFields} isArray>{(data.skills_tools || []).join(' • ')}</Highlight>
            {(data.skills_core?.length > 0 || data.skills_tools?.length > 0) && data.skills_soft?.length > 0 ? ' • ' : ''}
            <Highlight path="skills_soft" highlightedFields={highlightedFields} isArray>{(data.skills_soft || []).join(' • ')}</Highlight>
          </p>
        </section>
      )}

      {data.work_experience && data.work_experience.length > 0 && (
        <section className="mb-4 break-inside-avoid">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-black pb-1 mb-2">Experience</h2>
          {data.work_experience.map((job, index) => (
            <div key={index} className="mb-3 break-inside-avoid">
              <div className="flex justify-between items-baseline">
                <h3 className="font-bold"><Highlight path={`work_experience.${index}.title`} highlightedFields={highlightedFields}>{job.title || 'Job Title'}</Highlight></h3>
                <span className="text-xs font-mono">
                    <Highlight path={`work_experience.${index}.start_date`} highlightedFields={highlightedFields}>{job.start_date}</Highlight> - <Highlight path={`work_experience.${index}.end_date`} highlightedFields={highlightedFields}>{job.end_date || 'Present'}</Highlight>
                </span>
              </div>
              <p className="italic text-gray-800">
                <Highlight path={`work_experience.${index}.employer`} highlightedFields={highlightedFields}>{job.employer || 'Employer'}</Highlight>
                {job.location && (
                    <>, <Highlight path={`work_experience.${index}.location`} highlightedFields={highlightedFields}>{job.location}</Highlight></>
                )}
              </p>
              <ul className="list-disc list-outside pl-5 mt-1 space-y-1">
                {job.achievements?.map((ach, i) => (
                  <li key={i}><Highlight path={`work_experience.${index}.achievements.${i}`} highlightedFields={highlightedFields}>{ach}</Highlight></li>
                ))}
              </ul>
            </div>
          ))}
        </section>
      )}
      
      {data.education && data.education.length > 0 && (
        <section className="break-inside-avoid">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-black pb-1 mb-2">Education</h2>
          {data.education.map((edu, index) => (
             <div key={index} className="flex justify-between items-baseline mb-2">
                <div>
                  <h3 className="font-bold"><Highlight path={`education.${index}.degree`} highlightedFields={highlightedFields}>{edu.degree || 'Degree'}</Highlight></h3>
                  <p className="italic text-gray-800"><Highlight path={`education.${index}.institution`} highlightedFields={highlightedFields}>{edu.institution || 'Institution'}</Highlight></p>
                </div>
                <span className="text-xs font-mono"><Highlight path={`education.${index}.graduation_date`} highlightedFields={highlightedFields}>{edu.graduation_date || ''}</Highlight></span>
              </div>
          ))}
        </section>
      )}
    </div>
  );
};

export default TemplateA;