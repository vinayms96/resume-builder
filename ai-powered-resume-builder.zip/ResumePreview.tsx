
import React from 'react';
import { Resume, Template, TEMPLATE_OPTIONS } from '../types';
import TemplateA from './preview_templates/TemplateA';
import TemplateB from './preview_templates/TemplateB';

interface ResumePreviewProps {
  resumeData: Resume;
  template: Template;
  onTemplateChange: (template: Template) => void;
  highlightedFields: Set<string>;
}

const ResumePreview: React.FC<ResumePreviewProps> = ({ resumeData, template, onTemplateChange, highlightedFields }) => {
  const renderTemplate = () => {
    switch (template) {
      case 'B': return <TemplateB data={resumeData} highlightedFields={highlightedFields} />;
      // Add cases for C, D, E, F here when implemented
      default: return <TemplateA data={resumeData} highlightedFields={highlightedFields} />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 sticky top-8">
       <div className="mb-4">
        <label htmlFor="template-select" className="block text-sm font-medium text-gray-700 mb-1">Template</label>
        <select 
          id="template-select"
          value={template}
          onChange={(e) => onTemplateChange(e.target.value as Template)}
          className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-gray-900"
        >
          {TEMPLATE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
        </select>
       </div>
       <div className="bg-white p-2 sm:p-4 md:p-8 border border-gray-200 shadow-inner min-h-[800px]">
          {renderTemplate()}
       </div>
    </div>
  );
};

export default ResumePreview;
